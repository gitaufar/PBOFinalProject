/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Quiz;

/**
 *
 * @author ammar
 */
public class Main {
    static int tahunSekarang = 2024;
    
    static void cariFilm(Pelanggan pelanggan,String judul){
        for(int i = 0;i < pelanggan.listFilm.length; i++){
            if(pelanggan.listFilm[i].judul.equalsIgnoreCase(judul)){
                System.out.println("Film " + judul + " ada");
                return;
            }
        }
        System.out.println("Film yang anda cari tidak ada");
    }
    
    static void cariFilm(Pelanggan pelanggan,int tahun){
        for(int i = 0;i < pelanggan.listFilm.length; i++){
            if(pelanggan.listFilm[i].tahun == tahun){
                System.out.println("-" + pelanggan.listFilm[i].judul);
            }
        }
    }
    
    static public Film buatFilm(String judul,String genre,String umur,int tahun){
        Film film;
        if(tahunSekarang - tahun > 5){
            film = new FilmReguler(judul,genre,umur,tahun);
        } else {
            film = new FilmNew(judul,genre,umur,tahun);
        }
        return film;
    }
    
    public static void main(String[] args) {
        
        Film avenger = buatFilm("AVENGER","AKSI","R18",2017);
        Film agalain = buatFilm("AGAK LAEN","KOMEDI","R13",2024);
        Film lawas = buatFilm("LAWAS","JADUL","R50",500);
        Film terbaru = buatFilm("TERBARU","BARU","R0",2024);
        
        
        Film[] listFilm = {avenger,agalain,lawas,terbaru};
        
        Pelanggan budi = new Pelanggan("budi","F111","reguler",62812345);
        
        budi.listFilm = listFilm;
        cariFilm(budi,"avenger");
        cariFilm(budi,2024);
        budi.ambilListFilm();
        
        
    }
}
