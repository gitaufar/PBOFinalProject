/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Quiz;

/**
 *
 * @author ammar
 */
public interface Menonton {
    public void ambilListFilm();
    public void tontonFilm(Film film);
}
