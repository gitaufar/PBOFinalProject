/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Quiz;

/**
 *
 * @author ammar
 */
public class FilmNew extends Film {
    
    public FilmNew(String judul,String genre,String kategoriUmur,int tahun){
        super(judul,genre,kategoriUmur,tahun);
    }
    
}
